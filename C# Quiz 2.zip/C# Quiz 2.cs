﻿using System;

namespace Quiz2
{
    class menu
    {
        static void Main(string[] args)
        {
            double total = 0;

            Console.WriteLine("-------Welcome to Baldi's Kitchen-------");
            Console.WriteLine("Chicken  Pizza  Spagetti  Steak");
            Console.WriteLine(" $20.00  $25.00   $15.00   $35.00");
            Console.WriteLine("Please select your meal (C - Chicken, P - Pizza, S - Spagetti, T - Steak");
            char menuChoice = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("How many people are in your party?: ");
            double amount = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Would you like to try out Baldi's Homeade Cheesecake for $10 per party? (y/n): ");
            char cheesecake = Convert.ToChar(Console.ReadLine());

            if (menuChoice == 'C')
            {
                total = 20.00 * amount;
                if (cheesecake == 'y')
                {
                    total += 10;
                }
            }
            else if (menuChoice == 'P')
            {
                total = 25.00 * amount;
                if (cheesecake == 'y')
                {
                    total += 10;
                }
            }
            if (menuChoice == 'S')
            {
                total = 15.00 * amount;
                if (cheesecake == 'y')
                {
                    total += 10;
                }
            }
            else if (menuChoice == 'T')
            {
                total = 35.00 * amount;
                if (cheesecake == 'y')
                {
                    total += 10;
                }
            }
                Console.WriteLine("");

                Console.WriteLine("Your total today is: ", total);
                Console.WriteLine(total);

            Console.WriteLine("Your order was ", menuChoice);
            Console.WriteLine(menuChoice);
            if (menuChoice == 'C')
            {
                Console.WriteLine("Chicken");
            }
            else if (menuChoice == 'P')
            {
                Console.WriteLine("Pizza");
            }
            if (menuChoice == 'S')
            {
                Console.WriteLine("Spagetti");
            }
            else if (menuChoice == 'T')
            {
                Console.WriteLine("Steak");
            }
            Console.WriteLine("For the party of ", amount);
            Console.WriteLine(amount);
            Console.WriteLine("Cheesecake included: ", cheesecake);
            Console.WriteLine(cheesecake);
        }
    }
}
