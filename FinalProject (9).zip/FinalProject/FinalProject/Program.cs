﻿using System;

namespace FinalProject
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            search findPet = new search();

            int size = 16;
            string[,] pets = new string[,] {
                { "rooney", "Golden Doodle", "4", "Dog", "Up to date on shots", "Rooney a loving, hyper" +
                  " golden doodle has been with us for about a year now. Over the course of the year we have" +
                  " seen him become more and more comfortable with other dogs and now never is alone at " +
                  "playtime. He is a very energetic dog that loves human and other dog attention. He constantly " +
                  "wants to be the center of attention and would be an amazing dog for a family or a couple " +
                  "that enjoys outdoor time. Rooney is the most loving dog and can't wait to find his forever home."
                },
                {
                  "bailey", "Chocolate lab Husky","2", "Dog", "Not up to date on shots", "Bailey " +
                  "was rescued from an unhappy home and it took awhile for her to warm up to us but is now " +
                  "the sweetest dog we have here. She is a beautiful chocolate husky lab mix and is very " +
                  "in tune with human emotions. Overall a very smart, loving dog that can't wait to find " +
                  "her forever home."
                },
                {
                  "naruto", "Golden Retriever", "3", "Dog", "Not up to date on shots", "Naruto is " +
                  "definitely the most energetic dog in Happy Homes. He loves attention and has the stamina " +
                  "of a cross country runner. He is not yet up tp date with his shots, but does not have " +
                  "a problem with humans or other dogs. Naruto was found on the streets of Pomona, and we " +
                  "expected a lot of skittishness from him, but even though he was abandoned, he showed " +
                  "us nothing but love and licks."
                },
                {
                  "gon", "Shituz", "3", "Dog", "Up to date on shots", "Gon, the cutest shih tzu and " +
                  "a big explorer. She loves to sniff around the yard and keeps mainly to herself " +
                  "but also loves human interaction and pets. Yummy Chummies being her favorite treat" +
                  ", she has a good appetite and is a very healthy, lovable dog that is looking for her " +
                  "new home."
                },
                {
                  "sasuke", "Boxer", "2", "Dog", "Up to date on shots", "Sasuke is a tenacious little guy" +
                  ", although he is not too little. Weighing in at 65 pounds Sasuke is a big dog with a lot " +
                  "of energy that he needs to get out. He would find the best home with a backyard or a park nearby " +
                  "to run around and be able to stretch those legs of his. Would be a great hiking dog " +
                  "because he already listens very well for a rescue dog. "
                },
                {
                  "kiba", "Corgi", "2", "Dog", "Not up to date on shots", "Kiba a cute little corgi has " +
                  "a bit of separation anxiety from others. She loves to be pet and even held, but will cry when " +
                  "put in her kennel. Requires a lot of attention but could be a great emotional support dog " +
                  "for someone, or even a family dog with a big family to give lots of love to."
                },
                {
                  "akamaru", "Black Labrador", "4", "Dog", "Up to date on shots", "Akamaru is the happiest " +
                  "lab you'll ever meet. He loves to run around the yard and has a lot of built up energy. " +
                  "He gets along well with all the other dogs and it is clear that he would be a great family dog. " +
                  "Already up to date with his shots he is ready to get up and finally find his home and family."
                },
                {
                  "hinata", "Persian", "4", "Cat", "Not up to date on shots", "Hinata a beautiful persian " +
                  "cat and only four years old. Hinata while she is not currently up to date with shots " +
                  "has had no problem in the vet room so far. She is  playful little thing even liking to " +
                  "mess with some of the dogs having them chase her around. "
                },
                {
                  "sakura", "Bengal", "9", "Cat", "Up to date on shots", "Sakura is an older cat but " +
                  "has a long life ahead of her. If you're wanting a low maintenance pet but someone " +
                  "to keep company during the long winter nights, Sakura is the cat for you. Loves cuddles " +
                  "but is also very independent."
                },
                {
                  "killua", "Golden Doodle", "2", "Dog", "Up to date on shots", "Killua came to Happy Homes a " +
                  "little skittish, but that can be expected when you're in a new environment. Killua is a " +
                  "lovable golden doodle that can always be found with a tennis ball in his mouth " +
                  "and running towards someone to play with him. At only 2 years old Killua is wanting to " +
                  "find a forever home to live a long happy life at. "
                },
                {
                  "boruto", "Husky", "1", "Dog", "Up to date on shots", "Boruto is are favorite husky " +
                  "here at Happy Homes. He is energetic but loves to cuddle and outside time is " +
                  "by far his favorite time of the day. Boruto is looking for a home that he can " +
                  "feel comfortable and give all the love he has to give to someone."
                },
                {
                  "shikamaru", "Corgi", "1", "Dog", "Up to date on shots", "A dog’s eye color is " +
                  "determined by the amount of melanin found in the iris. Brown eyes indicate a high " +
                  "concentration of melanin, while green or blue eyes indicate a lower amount. Dogs " +
                  "with two different colored eyes have differing melanin levels in each eye. " +
                  "Heterochromia, however, can also be centralized. That is, the iris of one " +
                  "eye can be two different colors. Shikamaru is a corgi with these eyes which makes him the " +
                  "cutest dog ever."
                },
                {
                  "kakashi", "Golden Retriever", "2", "Dog", "Up to date on shots", "Kakashi is the happiest " +
                  "lab you'll ever meet. He loves to run around the yard and has a lot of built up energy. " +
                  "He gets along well with all the other dogs and it is clear that he would be a great family dog. " +
                  "Already up to date with his shots he is ready to get up and finally find his home and family."
                },
                {
                  "asuma", "Husky", "2", "Dog", "Not up to date on shots", "Sasuke is a tenacious little guy" +
                  ", although he is not too little. Weighing in at 65 pounds Sasuke is a big dog with a lot " +
                  "of energy that he needs to get out. He would find the best home with a backyard or a park nearby " +
                  "to run around and be able to stretch those legs of his. Would be a great hiking dog " +
                  "because he already listens very well for a rescue dog."
                },
                {
                  "minato", "Golden Retriever", "3", "Dog", "Not up to date on shots", "Minato came to Happy Homes a " +
                  "little skittish, but that can be expected when you're in a new environment. Minato is a " +
                  "lovable golden doodle that can always be found with a tennis ball in his mouth " +
                  "and running towards someone to play with him. At only 2 years old Minato is wanting to " +
                  "find a forever home to live a long happy life at."
                },
                {
                  "seigetsu", "Shituz", "3", "Dog", "Up to date on shots", "Seigetsu, the cutest shih tzu and " +
                  "a big explorer. She loves to sniff around the yard and keeps mainly to herself " +
                  "but also loves human interaction and pets. Yummy Chummies being her favorite treat" +
                  ", she has a good appetite and is a very healthy, lovable dog that is looking for her " +
                  "new home."
                }

            };

        findPet.display(pets, size);
            findPet.loop(pets, size);
        }
    }
}