﻿using System;

namespace Final
{
    class MainClass
    {
        public static void Main(string[] args)
        {

            Outcome MyOutcome = new Outcome();

                string[] items = { "lego star wars", "cookie", "", "", "" };
                int[] itemsPrice = { 25, 5, 0, 0, 0};                
                bool outerLoop = false;
                int buyTotal = 0;
                int refundTotal = 0;
                int userChoice;
                int userChoiceSubMenu;
                int counter = 2;
                int customerCounter = 0;
                userChoice = MyOutcome.menu();

            do
            {
                bool loop = false;
                switch (userChoice)
                {

                    case 1:
                        string buy;
                        int tempPrice;

                        do
                        {
                            Console.WriteLine("Which item would you like to buy?");
                            buy = Console.ReadLine();
                            buy = buy.ToLower();
                            if (buy == items[0])
                            {
                                tempPrice = itemsPrice[0];
                                buyTotal += tempPrice;
                            }
                            if (buy == items[1])
                            {
                                tempPrice = itemsPrice[1];
                                buyTotal += tempPrice;
                            }
                            if (buy == items[2])
                            {
                                tempPrice = itemsPrice[2];
                                buyTotal += tempPrice;
                            }
                            if (buy == items[3])
                            {
                                tempPrice = itemsPrice[3];
                                buyTotal += tempPrice;
                            }
                            if (buy == items[4])
                            {
                                tempPrice = itemsPrice[4];
                                buyTotal += tempPrice;
                            }
                            Console.WriteLine("Anything else?");
                            char continueLoop = Convert.ToChar(Console.ReadLine());
                            if (continueLoop == 'n' || continueLoop == 'N')
                            {
                                loop = true;
                            }
                        }
                        while (loop == false);
                        customerCounter++;
                        Console.WriteLine("Your total was $" + buyTotal);
                        Console.WriteLine("Thank you for shopping at Target");
                        Console.WriteLine();
                        userChoice = MyOutcome.menu();
                        break;
                    case 2:
                        string returning;
                        int tempRefund;

                        do
                        {
                            Console.WriteLine("Which item would you like to return?");
                            returning = Console.ReadLine();
                            returning = returning.ToLower();
                            if (returning == items[0])
                            {
                                tempRefund = itemsPrice[0];
                                refundTotal += tempRefund;
                            }
                            if (returning == items[1])
                            {
                                tempRefund = itemsPrice[1];
                                refundTotal += tempRefund;
                            }
                            if (returning == items[2])
                            {
                                tempRefund = itemsPrice[2];
                                refundTotal += tempRefund;
                            }
                            if (returning == items[3])
                            {
                                tempRefund = itemsPrice[3];
                                refundTotal += tempRefund;
                            }
                            if (returning == items[4])
                            {
                                tempRefund = itemsPrice[4];
                                refundTotal += tempRefund;
                            }
                            Console.WriteLine("Anything else?");
                            char continueLoop = Convert.ToChar(Console.ReadLine());
                            if (continueLoop == 'n' || continueLoop == 'N')
                            {
                                loop = true;
                            }
                        }
                        while (loop == false);
                        customerCounter++;
                        Console.WriteLine("Your refund total was $" + refundTotal);
                        Console.WriteLine("Thank you for shopping at Target");
                        Console.WriteLine();

                        userChoice = MyOutcome.menu();
                        break;

                    case 3:
                        do
                        {

                            Console.WriteLine("\n1) Add New Item\n2) Remove item\n3) Main Menu");
                            userChoiceSubMenu = Convert.ToInt32(Console.ReadLine());

                            switch (userChoiceSubMenu)
                            {
                                case 1:
                                    Console.WriteLine("ADD ITEM");
                                    Console.WriteLine("Item Name: ");
                                    items[counter] = Convert.ToString(Console.ReadLine());
                                    Console.WriteLine("Item Price: ");
                                    itemsPrice[counter] = Convert.ToInt32(Console.ReadLine());
                                    counter++;
                                    break;

                                case 2:
                                    string remove;

                                    Console.WriteLine("Which item would you like to remove?");
                                    remove = Console.ReadLine();

                                    if (remove == items[0])
                                    {
                                        items[0] = "";
                                        itemsPrice[0] = 0;

                                    }
                                    if (remove == items[1])
                                    {
                                        items[1] = "";
                                        itemsPrice[1] = 0;
                                    }
                                    if (remove == items[2])
                                    {
                                        items[2] = "";
                                        itemsPrice[2] = 0;
                                    }
                                    if (remove == items[3])
                                    {
                                        items[3] = "";
                                        itemsPrice[3] = 0;
                                    }
                                    if (remove == items[4])
                                    {
                                        items[4] = "";
                                        itemsPrice[4] = 0;
                                    }
                                    Console.WriteLine("Item Removed Succesfully");
                                    break;
                                case 3:
                                    loop = true;
                                    break;
                            }
                        } while (loop == false);
                        userChoice = MyOutcome.menu();
                        break;
                    case 4:
                        int tempProfit = buyTotal - refundTotal;
                        Console.WriteLine("Reports:");
                        Console.Write("Total Customers: ");
                        Console.WriteLine(customerCounter);
                        Console.Write("Total Profits: $");
                        Console.WriteLine(tempProfit);
                        Console.WriteLine();
                        loop = true;
                        userChoice = MyOutcome.menu();
                        break;
                    case 5:
                        outerLoop = true;
                        break;
                }
            } while (outerLoop == false);
                
            }
        }
    }
