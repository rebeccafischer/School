﻿using System;
namespace Final
{
    public class Outcome
    {
        public int menu()
        {
            int userChoice;
            Console.WriteLine("Welcome to Target\nChoose the following options:\n1) Make a Purchase\n2) Make a Return\n3) Manage Inventory\n4) View Report\n5) Exit Menu\n");
            userChoice = Convert.ToInt32(Console.ReadLine());
            return userChoice;

        }

        public int subMenu()
        {
            int userChoice;
            Console.WriteLine("1) Add New Item\n2) Remove item\n3) Main Menu\n");
            userChoice = Convert.ToInt32(Console.ReadLine());
            return userChoice;

        }


    }
}
