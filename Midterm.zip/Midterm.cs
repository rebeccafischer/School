﻿using System;

namespace Midterm
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string[] food = { "Pizza", "Seafood", "Chicken" };
                int[] foodPrices = { 10, 12, 8 };
                string[] drink = { "Sprite", "Horchata", "Chocolate milk" };
                int[] drinkPrices = { 3, 2, 1 };
                string[] dessert = { "Icecream", "Brownie", "Cinnamon roll" };
                int[] dessertPrices = { 2, 1, 3 };
                double total = 0;
                Console.WriteLine("Welcome to Becca's Kitchen!");
                Console.WriteLine("------------- Food --------------");
                for (int i = 0; i < food.Length; i++)
                {
                    Console.WriteLine(food[i] + " $" + foodPrices[i]);

                }
                Console.WriteLine("Choose your food: ");
                string user = Console.ReadLine();
                for (int i = 0; i < food.Length; i++)
                {
                    if (food[i] == "Pizza")
                    {
                        total = 10;
                    }
                    else if (food[i] == "Chicken")
                    {
                        total = 8;
                    }
                    else if (food[i] == "Seafood")
                    {
                        total = 12;
                    }
                }

                for (int i = 0; i < drink.Length; i++)
                {
                    Console.WriteLine(drink[i] + " $" + drinkPrices[i]);
                    if (drink[i] == "Sprite")
                    {
                        total = 3;
                    }
                    else if (drink[i] == "Horchata")
                    {
                        total = 2;
                    }
                    else if (drink[i] == "Chocolate milk")
                    {
                        total = 1;
                    }
                }
                Console.WriteLine("Choose your drink: ");
                string userIn = Console.ReadLine();

                Console.WriteLine("Would you like dessert? y/n");
                string dessertChoice = Console.ReadLine();
                if (dessertChoice == "y")
                {
                    for (int i = 0; i < dessert.Length; i++)
                    {
                        Console.WriteLine(dessert[i] + " $" + dessertPrices[i]);
                        if (dessert[i] == "Icecream")
                        {
                            total = 2;
                        }
                        else if (dessert[i] == "Brownie")
                        {
                            total = 1;
                        }
                        else if (dessert[i] == "Cinnamon roll")
                        {
                            total = 3;
                        }
                    }
                    Console.WriteLine("Choose your dessert: ");
                    string userInput = Console.ReadLine();
                }
                Console.WriteLine("Would you like to place another order?: y/n");
                char userChoice = Convert.ToChar(Console.ReadLine());
                if (userChoice == 'n')
                {
                    break;
                }

                Console.WriteLine("Your total is: ");
                
                Console.WriteLine("Now your fortune cookie quote is ");

                Console.WriteLine("Enter a number 1-10: ");
                string number = Console.ReadLine();

                switch (number)
                {
                    case "1":
                        Console.WriteLine("You will have great success in the near future.");
                        break;
                    case "2":
                        Console.WriteLine("You will meet someone special soon.");
                        break;
                    case "3":
                        Console.WriteLine("You will be happy.");
                        break;
                    case "4":
                        Console.WriteLine("You will earn a lot of money.");
                        break;
                    case "5":
                        Console.WriteLine("You will find a penny.");
                        break;
                    case "6":
                        Console.WriteLine("You will do great things.");
                        break;
                    case "7":
                        Console.WriteLine("You will meet someone special soon.");
                        break;
                    case "8":
                        Console.WriteLine("You will meet someone special soon.");
                        break;
                    case "9":
                        Console.WriteLine("You will meet someone special soon.");
                        break;
                    case "10":
                        Console.WriteLine("You will meet someone special soon.");
                        break;
                }

            }
        }
    }
}


    
    
    

